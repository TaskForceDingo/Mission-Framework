To install these compositions, locate your Arma 3 profile compositions folder in:
    
    C:\Users\YOURUSER\Documents\Arma 3 - Other Profiles\YOURARMA3PROFILE\compositions\

Then paste all of the named folders into this directory. If you already have the editor open,
you will need to close the editor then re-open it in order to refresh the compositions list


